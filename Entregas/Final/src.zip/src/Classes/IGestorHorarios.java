package Classes;

public interface IGestorHorarios {
    void getAlunos();
    void getUCs();
    void getTurnos();
    void load_data();
    boolean isDataLoaded();
    void gerarHorarios();
}