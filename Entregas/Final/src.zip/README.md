# DSS2425-Grupo-25

In this repository, we will be working on the project for the course DSS:

For the first milestone, we will be working on the following tasks:

- Relatório: [Relatório](/relatorio/relatorio.pdf)

The extra files to this milestone are stored in the following folders: [relatorio/files](/relatorio/files)

# Notes

- Due to time limitations, we were not able to implement the full functionality of a login system and password management, so we decided to use a simple login system with a hardcoded password for the data thats imported without one being provided. That password is "password".
- Also first time running the application you should run the SQL script in the files in the `data` folder to create the database and tables. And to populate, if needed.